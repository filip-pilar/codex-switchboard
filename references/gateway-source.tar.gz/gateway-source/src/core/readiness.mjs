export const readinessPath = "/__llm_local_gateway/readiness";
export const legacyReadinessPath = "/__llm_gateway/readiness";
